
/*
 * Adam Stammer
 * Heap Reader
 * 11/20/2018
 * Written for the CS 341 Exam 2 at Winona State University
 * 
 * The purpose of this application is to read text data from an input file
 * and determine if the given data represents a heap or not
 */

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class HeapReader {

	public static void main(String[] args) {

		int[][] intLists = readLists("heap.dat"); // read in the data

		for (int x = 0; x < intLists.length; x++) { // loop through each list and check for heapness
			System.out.print("Line " + (x + 1) + ": ");
			if (isHeap(intLists[x])) {
				System.out.println("Yeah, that's a heap!");
			} else
				System.out.println("Nope, that's no heap!");
		}
	}

	public static boolean isHeap(int[] list) {
		for (int i = 1; i < list.length; i++) {// check each node
			if (list[i] < list[(i - 1) / 2]) {// if the child is bigger, not a heap
				return false;
			}
		}
		return true; // otherwise we pass all the tests and it is a heap
	}

	public static int[][] readLists(String fileName) {
		FileReader fr = null; // setup a file reader and open the file
		try {
			fr = new FileReader(fileName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		char c[] = new char[500];
		try {
			fr.read(c);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // read from the file and then split the data into a string list
		String s = new String(c); // this is our string of data
		String lists[] = s.split("\n");
		for (int i = 0; i < lists.length; i++) {
			lists[i] = lists[i].trim();
		}
		// now that we have our string lists, let's turn them into integer lists

		int[][] intLists = new int[lists.length][];
		for (int x = 0; x < lists.length; x++) { // loop through each string list
			intLists[x] = integize(lists[x]); // and turn it into an integer list
		}

		return intLists;
	}

	public static int[] integize(String list) {
		// prepare to store the lists in int form
		int[] intList = null;
		// loop through each list
		for (int i = 0; i < list.length() - 1; i++) {
			// split the numbers by space
			String[] lis = list.split(" ");
			intList = new int[lis.length];
			// loop through each string in the list
			for (int j = 0; j < lis.length; j++) {
				// and store them as integers
				intList[j] = Integer.parseInt(lis[j]);
			}
		}

		return intList;
	}
}
