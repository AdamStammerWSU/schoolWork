function [x0,k]=sorSolve(A,b,x0,maxIters)
% skeleton for sorSolve function 

x0=zeros(size(b)); 




for k=1:maxIters
   


end



end