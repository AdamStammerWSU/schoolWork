Homesite for bookbinder -www.quantumelephant.co.uk/bookbinder/bookbinder.html
E-Mail			-pangolin@quantumelephant.co.uk	

This archive should contain :-

		bookbinder-3.0.jar 	-the main program, a Java jar file
		source			-the source directory
		readme.txt		-this file

Bookbinder is really a simple script that calls some classes of the itext Java library, so most of the 
credit is due to Bruno Lowagie, who writes and maintains itext. The PDF viewer code is provided by the JPedal 
Java library. All I have done is written a script to solve a problem that I was having difficulty finding a 
solution to.


Feature requests, bug reports and/or encouragement to the e-mail address above.