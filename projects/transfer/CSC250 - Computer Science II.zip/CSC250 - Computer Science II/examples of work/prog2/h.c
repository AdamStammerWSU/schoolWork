//desciription
//name and date
//course name and section

#include <stdio.h>

int main() {
	printf("Poly Pong...\n");
	return 0;
}


//description
//data passed into
//data from
int mitchell() {
	return 0;
}