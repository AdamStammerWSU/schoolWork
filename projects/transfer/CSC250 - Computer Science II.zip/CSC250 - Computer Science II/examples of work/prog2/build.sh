gcc-4.9 -o h h.c
