flatten_append(L1, L2, L3) :-
	flatten(L1,F1),
	flatten(L2,F2),
	append(F1, F2, L3).
flatten_append1(L1, L2, L3) :-
	append(L1, L2, U3),
	flatten(U3, L3).

combine(L1, L2, L3, L4) :-
	reverse(L2, R2),
	append(L1, R2, C1),
	append(C1, L3, L4).

rev([],[]).
rev([H|T],L) :-
	rev(T,M),
	append(M,[H],L).

rev1(L,R) :-
	rev2(L,R,[]).
rev2([],A,A).
rev2([H|T],R,A) :-
	rev2(T,R,[H|A]).

len([],0).
len([_|T],L) :-  
	len(T,X),
	L is X + 1.

len1(List,Len) :- 
	len1(List,Len,0).
len1([],Acc,Acc).
len1([_|T],Len,Acc) :- 
	NewAcc is Acc + 1, 
	len1(T,Len,NewAcc).

fact(0,1).
fact(N,R) :-
	N > 0,
	N1 is N - 1,
	fact(N1,R1),
	R is N * R1.

fact1(N,F) :-
	fact1(N,F,1).
fact1(0,F,F).
fact1(N,F,A) :-
	N > 0,
	A1 is A * N,
	N1 is N - 1,
	fact1(N1,F,A1).

fib(0,1).
fib(1,1).
fib(N,M) :- 
	N > 0,
	N1 is N - 1,
	fib(N1,M1),
	N2 is N - 2,
	fib(N2,M2),
	M is M1 + M2.

fib1(N,M) :-
	fib2(N,[_,M]).
fib2(0,[0,1]).
fib2(N,[X,Y]) :-
	N > 0,
	N1 is N - 1,
	fib2(N1,[Z,X]),
	Y is Z + X.

sorted([]).
sorted([_]).
sorted([X,Y|Z]) :-
	X =< Y,
	sorted([Y|Z]).

permutation([],[]).
permutation(X,[Y|Z]) :-
	append(U,[Y|V],X),
	append(U,V,W),
	permutation(W,Z).

qsort([],[]).
qsort([H|T],S) :-
	partition(H,T,L,R),
	qsort(L,L1),
	qsort(R,R1),
	append(L1,[H|R1],S).

partition(P,[A|X],[A|Y],Z) :-
	A < P,
	partition(P,X,Y,Z).
partition(P,[A|X],Y,[A|Z]) :-
	A >= P,
	partition(P,X,Y,Z).
partition(_,[],[],[]).
