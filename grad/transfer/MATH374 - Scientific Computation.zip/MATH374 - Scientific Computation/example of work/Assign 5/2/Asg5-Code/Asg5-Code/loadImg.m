function img=loadImg(filename) 
   
   img=imread(filename);
   img=rgbToGray(img); 
   
   
   
  
  
  
  
  
  
end